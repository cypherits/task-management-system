<?php $this->load->view('dashboard/header') ?>
<div class="container-fluid">

</div>
<?php $this->load->view('dashboard/footer') ?>